import math
from tkinter import *

# ---------------------------- CONSTANTS ------------------------------- #
PINK = "#e2979c"
RED = "#e7305b"
GREEN = "#9bdeac"
YELLOW = "#f7f5dd"
FONT_NAME = "Courier"
WORK_MIN = 5
SHORT_BREAK_MIN = 3
LONG_BREAK_MIN = 10
reps=0
timer= None

# ---------------------------- TIMER RESET ------------------------------- # 
def reset_time():
    global timer, reps
    window.after_cancel(timer)
    label1.config(text="Timer", fg=GREEN)
    canvas.itemconfig(txt,text="00:00")
    check_mark_label.config(text="")
    reps=0


# ---------------------------- TIMER MECHANISM ------------------------------- #

def start_timer():
    global reps
    reps+=1
    work_sec=WORK_MIN*60
    short_break_sec=SHORT_BREAK_MIN*60
    long_break_sec=LONG_BREAK_MIN*60

    if reps in [1,3,5,7]:
        label1.config(text="Work", fg=GREEN)
        count_down(work_sec)
    elif reps==8:
        label1.config(text="Break", fg=RED)
        count_down(long_break_sec)
    else:
        label1.config(text="Break", fg=PINK)
        count_down(short_break_sec)

# ---------------------------- COUNTDOWN MECHANISM ------------------------------- # 
def count_down(count):
    global timer
    count_min=math.floor(count/60)
    count_sec=count%60
    if count_sec<10:
        count_sec=f"0{count_sec}"
    canvas.itemconfig(txt,text=f"{count_min}:{count_sec}")
    if count>0:
        timer=window.after(50,count_down,count-1)
    else:
        start_timer()
        marks=""
        work_sessions=math.floor(reps/2)
        for _ in range(work_sessions):
            marks+="✔"
        check_mark_label.config(text=marks)
# ---------------------------- UI SETUP ------------------------------- #
window=Tk()
window.title("Pomodoro")
window.config(padx=100,pady=50,bg=YELLOW)

canvas=Canvas(width=200,height=224,bg=YELLOW,highlightthickness=0) #highlightthickness=0 will get rid of the outline from this object
img=PhotoImage(file="tomato.png")

label1=Label(text="Timer",bg=YELLOW,fg=GREEN,font=(FONT_NAME,20,"bold") )
label1.grid(column=1, row=0)

canvas.create_image(100,112,image=img)
txt=canvas.create_text(100,130,text="00:00", fill="white", font=(FONT_NAME,35,"bold"))
canvas.grid(column=1,row=1)


start_btn=Button(text="Start", command=start_timer)
start_btn.grid(column=0,row=4)


reset_btn=Button(text="Reset", command=reset_time)
reset_btn.grid(column=2,row=4)


check_mark_label=Label(fg=GREEN,bg=YELLOW,font=(FONT_NAME,15,"bold"))
check_mark_label.grid(column=1,row=3)


from tkinter import messagebox

def show_popup():
    messagebox.showinfo("Instructions", "The Pomodoro Technique is a time management method that involves working in focused intervals followed by short breaks."
                                        "\n\nNote: This is a Demo Version, timer has been fast-forwarded for demonstration."
                                        "\n\nRep 1:"
                                        "\n\tWork: 5 mins"
                                        "\n\tShort Break: 3 mins"
                                         "\nRep 2:"
                                        "\n\tWork: 5 mins"
                                        "\n\tShort Break: 3 mins"
                                         "\nRep 3:"
                                        "\n\tWork: 5 mins"
                                        "\n\tShort Break: 3 mins"
                                        "\nRep 4:"
                                        "\n\tWork: 5 mins"
                                        "\n\tLong Break: 10 mins"
                                        "\n\n✔ denotes the number of repetation completed"
                                        "\nClick 'Start' button to start the timer"
                                        "\nClick 'Reset' button to reset the timer from 1st Rep"
                                        "\n\nCreated By: Hari Ravendran")

# Create a button and attach the pop-up function
button = Button(window, text="info", font=(FONT_NAME,10,"italic"),command=show_popup, highlightthickness=0)
button.grid(column=1,row=4)

window.mainloop()